Show Current Template
==========

A WordPress plugin which shows the current template file name, the current theme name and included template files' name in the tool bar.