<?php

namespace WhichBrowser\Data;

Applications::$OTHERS_REGEX = '/(itunes|qt|bluefish|nightingale|songbird|stagefright|substream|vlc|windows-media|coreplayer|flycast|boxee|kodi|xbmc|lightning|thunderbird|outlook|lotus|postbox|bat|yahoo|daum|akregator|blogos|cococ|feed|liferea|news|jetbrains|rss|reeder|reedkit|rome|ziepod|messenger|kik|yammer|fbios|fb4a|googleplus|instagram|weibo|tumblr|twitter|wp-android|office|hao123|gsa|naver|atom|golive|brackets|iweb|frontpage|amaya|download|origin|secondlife|valve|raptr|cooliris|google|leechcraft|expeditor)/i';
