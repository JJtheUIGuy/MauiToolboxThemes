<?php

namespace WhichBrowser\Data;

DeviceModels::$FIREFOXOS_MODELS = [
    'ALCATEL ONE TOUCH FIRE'                    => [ 'Alcatel', 'One Touch Fire' ],
    'ALCATEL ONE TOUCH 4012A'                   => [ 'Alcatel', 'One Touch Fire' ],
    'ALCATEL ONE TOUCH 4012X'                   => [ 'Alcatel', 'One Touch Fire' ],
    'ALCATELOneTouch4012A!'                     => [ 'Alcatel', 'One Touch Fire' ],
    'ALCATELOneTouch4012X!'                     => [ 'Alcatel', 'One Touch Fire' ],
    'OneTouch4019A'                             => [ 'Alcatel', 'One Touch Fire C' ],
    'ALCATELOneTouch4019A!'                     => [ 'Alcatel', 'One Touch Fire C' ],
    'ALCATELOneTouch4019X!'                     => [ 'Alcatel', 'One Touch Fire C' ],
    'ALCATELOneTouch4020D!'                     => [ 'Alcatel', 'One Touch Fire C' ],
    'ALCATELOneTouch4022!'                      => [ 'Alcatel', 'One Touch Pixi 3 (3.5)' ],
    'ALCATELOneTouch4023!'                      => [ 'Alcatel', 'One Touch Pixi 3 (3.5)' ],
    'ALCATELOneTouch6015X!'                     => [ 'Alcatel', 'One Touch Fire E' ],
    'HUAWEI Ascend Y300-F1'                     => [ 'Huawei', 'Ascend Y300 F1' ],
    'HUAWEIY300-F1'                             => [ 'Huawei', 'Ascend Y300 F1' ],
    'LG-D3(00|01)!'                             => [ 'LG', 'Fireweb' ],
    'LGL25'                                     => [ 'LG', 'Fx0' ],
    'madai'                                     => [ 'LG', 'Fx0' ],
    'Orange KLIF'                               => [ 'Orange', 'Kilf' ],
    'Orange KLIFD'                              => [ 'Orange', 'Kilf' ],
    'OPEN'                                      => [ 'ZTE', 'Open' ],
    'ZTEOPEN'                                   => [ 'ZTE', 'Open' ],
    'OpenC'                                     => [ 'ZTE', 'Open C' ],
    'Open C'                                    => [ 'ZTE', 'Open C' ],
    'OPENC2'                                    => [ 'ZTE', 'Open C2' ],
    'OPEN2'                                     => [ 'ZTE', 'Open II' ],
];
